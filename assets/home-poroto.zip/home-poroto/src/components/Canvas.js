import React from "react";
import Sketch from "react-p5";

let d;
let particles = [];

const Canvas = ({temperature, humidity}) => {
	const setup = (p5, canvasParentRef) => {
		p5.createCanvas(p5.windowWidth, p5.windowHeight).parent(canvasParentRef);
		p5.colorMode(p5.HSB, 360, 100, 100, 100);
		p5.frameRate(20);
		d = p5.pixelDensity();
		p5.background(0, 0, 0, 0)

		class Particle {
			constructor(_x, _y, _color) {
				this.x = _x;
				this.y = _y;
				this.clr = _color;

				this.incr = 0;
			}

			move() {
				this.update();
				this.wrap();
				this.display();
			}

			update() {
				this.incr += .008
				this.theta = p5.noise(this.x * p5.map(temperature, 70, 80, 0.001, 0.002), this.y * p5.map(humidity, 50, 70, 0.001, 0.002), this.incr) * p5.TWO_PI;
				this.x += p5.map(temperature, 70, 80, .5, 3) * p5.cos(this.theta);
				this.y += p5.map(humidity, 50, 70, .5, 3) * p5.sin(this.theta);
			}

			display() {
				for (let i = 0; i < d; i++) {
					for (let j = 0; j < d; j++) {
						// loop over
						let index = 4 * ((parseInt(this.y) * d + j) * p5.width * d + (parseInt(this.x) * d + i));
						p5.pixels[index] = p5.red(this.clr);
						p5.pixels[index + 1] = p5.green(this.clr);
						p5.pixels[index + 2] = p5.blue(this.clr);
						p5.pixels[index + 3] = p5.alpha(this.clr);
					}
				}
			}

			wrap() {
				if (this.x < 0) this.x = p5.width;
				if (this.x > p5.width) this.x = 0;
				if (this.y < 0) this.y = p5.height;
				if (this.y > p5.height) this.y = 0;
			}
		}

		particles = [];
		for (let i = 0; i < 6000; i++) {
			let x = p5.random(p5.width);
			let y = p5.random(p5.height);
			let adj = p5.map(y, 0, p5.height, 255, 0);
			let c = p5.color(40, adj, 255);
			c = p5.color(p5.map(temperature, 70, 80, 210, 0), 100, 100);
			particles.push(new Particle(x, y, c));
		}
	}

	const draw = (p5) => {
		const ratio =  p5.map(temperature, 70, 80, 20, 0) / p5.map(humidity, 50, 70, 20, 0);
		p5.fill(0, p5.map(ratio, 0, 1, 7, 3));
		p5.rect(0, 0, p5.width, p5.height);

		p5.loadPixels();
		particles.forEach((p) => {
			p.move();
		});
		p5.updatePixels();
	};

	const windowResized = (p5) => {
		p5.resizeCanvas(p5.windowWidth, p5.windowHeight);
	}

	return (
		<Sketch 
			setup={setup} 
			draw={draw} 
			windowResized={windowResized} 
			temperature={temperature}
			humidity={humidity}
		/>
	)
};

export default Canvas;
